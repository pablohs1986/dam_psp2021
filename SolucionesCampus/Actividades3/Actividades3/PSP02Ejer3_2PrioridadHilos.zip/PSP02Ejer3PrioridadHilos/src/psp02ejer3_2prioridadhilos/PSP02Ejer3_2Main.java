package psp02ejer3_2prioridadhilos;

import java.util.logging.Level;
import java.util.logging.Logger;

public class PSP02Ejer3_2Main {

    public static void main(String[] args) {

        Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        PSP02Ejer3_2PrioridadHilos hiloHIGH = new PSP02Ejer3_2PrioridadHilos(Thread.NORM_PRIORITY + 2, "hiloHIGH");
        PSP02Ejer3_2PrioridadHilos hiloLOW = new PSP02Ejer3_2PrioridadHilos(Thread.NORM_PRIORITY - 2, "hiloLOW");
        hiloLOW.start();
        hiloHIGH.start();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            System.out.println("Hilo principal interrumpido.");
        }
        hiloLOW.stop();
        hiloHIGH.stop();
        System.out.println("hiloLOW: "+ hiloLOW.hilo.isAlive()+" " +hiloLOW.hilo.getState());
        System.out.println("hiloHIGH: "+ hiloHIGH.hilo.isAlive()+" " +hiloHIGH.hilo.getState());
       //forzamos a que antes de continuar el proceso main se ejecuten
        // y finalicen hiloLOW y hiloHIGH  -- join()
        try {
            hiloLOW.hilo.join();
            hiloHIGH.hilo.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(PSP02Ejer3_2Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("hiloLOW: "+ hiloLOW.hilo.isAlive()+" " +hiloLOW.hilo.getState());
        System.out.println("hiloHIGH: "+ hiloHIGH.hilo.isAlive()+" " +hiloHIGH.hilo.getState());
     
    }
}
