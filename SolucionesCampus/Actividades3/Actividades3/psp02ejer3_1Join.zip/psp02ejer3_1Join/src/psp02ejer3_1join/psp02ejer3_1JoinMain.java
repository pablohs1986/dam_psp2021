package psp02ejer3_1join;

public class psp02ejer3_1JoinMain {

    public static void main(String[] args) {
        NewHilo ob1 = new NewHilo("Hilo1");
        NewHilo ob2 = new NewHilo("Hilo2");
        NewHilo ob3 = new NewHilo("Hilo3");
        System.out.println("Proceso activo: " + Thread.currentThread());
        System.out.println("El hilo1  esta vivo: " + ob1.t.isAlive());
        System.out.println("El hilo2  esta vivo: " + ob2.t.isAlive());
        System.out.println("El hilo3  esta vivo: " + ob3.t.isAlive());
        try {// espera hasta que terminen los otros hilos
            System.out.println("Espera finalizacion de los otros hilos.");
            ob1.t.join();
            ob2.t.join();
            ob3.t.join();
        } catch (InterruptedException e) {
            System.out.println("Interrupcion del hilo principal");
        }
        System.out.println("Vuelvo al hilo principal: " + Thread.currentThread());
        System.out.println("El hilo1  esta vivo: " + ob1.t.isAlive());
        System.out.println("El hilo2  esta vivo " + ob2.t.isAlive());
        System.out.println("El hilo3  esta vivo: " + ob3.t.isAlive());
        System.out.println("Sale del hilo principal.");
    }
}
