package modelo;

/*
usamos un solo hilo que podrá ser de entrada o salida
en funcion de un boolean, que se establecerá cuando
creemos el hilo
*/
public class HiloPersona extends Thread {

    private Jardin j;
    private boolean entrar;

    public boolean isEntrar() {
        return entrar;
    }

    public void setEntrar(boolean entrar) {
        this.entrar = entrar;
    }

    
    public HiloPersona(String nombreHilo, Jardin j, boolean entrar) {
        //asigamos la puerta de salida al jardin 
        //y un nombre a dicha puerta
        this.j = j;
        this.setName(nombreHilo); //atributo name del Thread
        this.entrar = entrar;
    }

    public void run() {
        
        j.entraSalirPersonaAlJardin(this);
        
      }
}
