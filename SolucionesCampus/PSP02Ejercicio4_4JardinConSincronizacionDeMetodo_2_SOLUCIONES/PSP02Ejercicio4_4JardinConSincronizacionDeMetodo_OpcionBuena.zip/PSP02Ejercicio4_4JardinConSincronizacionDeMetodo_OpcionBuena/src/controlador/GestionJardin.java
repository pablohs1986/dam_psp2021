package controlador;

import modelo.HiloPersona;
import modelo.Jardin;



public class GestionJardin {

    public static void main(String[] args) {
        //creamos el jardin ya con 100 personas
        Jardin jardinCiudad = new Jardin(100);
        int valor;
        boolean entrar=false;     
        String nombreHilo;
        
        for(int i=1; i<=30;i++){
            valor = (int) (Math.random()*2);
            switch(valor){
               case 0:  entrar = true;
                     break;
               case 1:  entrar = false;
                     break;
            }
            nombreHilo= "P"+i;
            System.out.println("Creando el hilo "+nombreHilo+" que"+(entrar?"Entra":"Sale"));
            new HiloPersona(nombreHilo,jardinCiudad,entrar).start();
        }
        

    }
}
