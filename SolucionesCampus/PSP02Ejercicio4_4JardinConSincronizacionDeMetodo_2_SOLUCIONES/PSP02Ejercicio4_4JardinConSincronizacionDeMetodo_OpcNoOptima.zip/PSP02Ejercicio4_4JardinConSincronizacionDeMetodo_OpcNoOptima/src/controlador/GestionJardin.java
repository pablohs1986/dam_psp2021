package controlador;


import modelo.HiloPuertaSalida;
import modelo.Jardin;
import modelo.HiloPuertaEntrada;

/*
Como existen dos hilos que llaman a métodos distintos es verdad
que soluciona el problema del ejercicio anterior y si dos hilos
quieren entrar solo 1 ejecutará el metodo bloqueando al otro

PERO NO SOLUCIONA EL PROBLEMA DEL CONTADOR EN EL CASO
DE QUE UN HILO ENTRE Y OTRO HILO SALGA, ya que cada hilo
llamará a su correspondiente método accediendo los dos al 
contador a la vez. Además la visualización en pantalla al ser
un recurso solo implica que se pueden mezclar mensajes del 
método que entra y del método que sale y puede dar la 
sensación que la ejecución no es correcta
*/
public class GestionJardin {

    public static void main(String[] args) {
        //creamos el jardin ya con 100 personas
        Jardin jardinCiudad = new Jardin(100);
         
        
        for(int i=1; i<=10;i++){
            new HiloPuertaEntrada("entra "+i,jardinCiudad).start();
        }
        
        for(int j=1; j<=15;j++){
            new HiloPuertaSalida("sale "+j,jardinCiudad).start();
        }
    }
}
